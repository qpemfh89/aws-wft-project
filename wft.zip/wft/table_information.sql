CREATE TABLE customers (
    customer_id INT AUTO_INCREMENT PRIMARY KEY,
    user_type ENUM('학생', '직원') NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    gender ENUM('남', '녀') NOT NULL,
    age INT NOT NULL
);